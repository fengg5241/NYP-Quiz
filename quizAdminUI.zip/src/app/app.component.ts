import { Component, OnInit } from '@angular/core';
import {AuthService,SocialUser} from 'angular-6-social-login';
import { Router } from '@angular/router';
import { Inject, Injectable } from '@angular/core';
import { SESSION_STORAGE, StorageService } from 'angular-webstorage-service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})


@Injectable()
export class AppComponent implements OnInit{
  title = 'Admin Dashboard';

  // key that is used to access the data in local storage
  STORAGE_KEY = 'quiz_admin_user';

  constructor(private authService: AuthService,
    private router: Router,
    @Inject(SESSION_STORAGE) private storage:StorageService) { }
   
  user: SocialUser;

  ngOnInit() {
    this.authService.authState.subscribe((user) => {
      this.user = user;
      var isLogin = this.storage.get(this.STORAGE_KEY);
      if(!isLogin){
        this.router.navigate(['login']);
      }
    });
  }

  signOut(): void {
    this.authService.signOut().then(
      (userData) => {
          this.storage.set(this.STORAGE_KEY, 0);
          this.router.navigate(['login']);    
      }
    );;
  }
}


