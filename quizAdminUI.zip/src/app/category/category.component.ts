import { Component, OnInit } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {

  model = {
    left: true,
    middle: false,
    right: false
  };

  categories:any;

  constructor(private http: HttpClient) { }

  ngOnInit() {
    //search all categories
    this.http.get('http://localhost:3000/category/getCategories').subscribe(data => {
      this.categories = data;
    });
  }





}
