import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Location } from '@angular/common';
import {  FileUploader } from 'ng2-file-upload/ng2-file-upload';

// define the constant url we would be uploading to.
const URL = 'http://localhost:3000/campaign/upload';

@Component({
  selector: 'app-campaign',
  templateUrl: './campaign.component.html',
  styleUrls: ['./campaign.component.css']
})
export class CampaignComponent implements OnInit {
  public uploader: FileUploader = new FileUploader({url: URL, itemAlias: 'photo'});
  uploadedFileName:String;
  serverUploadFolder = "http://localhost:3000/images/uploads/campaign/";
  constructor(private http: HttpClient,
    private location: Location) { }

  ngOnInit() {
     // override the onAfterAddingfile property of the uploader so it doesn't authenticate with //credentials.
        this.uploader.onAfterAddingFile = (file) => { file.withCredentials = false;};
     // \\overide the onCompleteItem property of the uploader so we are
     // able to deal with the server response.
    this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
          this.uploadedFileName = JSON.parse(response).filename;
          alert("Upload Successful !");
          console.log('ImageUpload:uploaded:', item, status, response);
      };
  }
  
  campaignTitle:any;
  //noOfQuestions:any;
  campaignReleaseDate:any;
  campaignEndDate:any;
  todayDateTime = new Date().toISOString().slice(0,10);

  createCampaign(){
    this.http.post('http://localhost:3000/campaign/createCampaign',{data:{
      name:this.campaignTitle,
      utcRelease:this.campaignReleaseDate,
      utcEnd:this.campaignEndDate,
      image:this.uploadedFileName,
    }}).subscribe(data => {
      this.location.back();
    });
  }



}