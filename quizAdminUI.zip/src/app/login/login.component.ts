import { Component, OnInit } from '@angular/core';
import {
  AuthService,
  FacebookLoginProvider,
  GoogleLoginProvider,
  SocialUser
} from 'angular-6-social-login';
import { Router } from '@angular/router';
import { Inject, Injectable } from '@angular/core';
import { SESSION_STORAGE, StorageService } from 'angular-webstorage-service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

@Injectable()
export class LoginComponent implements OnInit {

  user: SocialUser;
// key that is used to access the data in local storage
 STORAGE_KEY = 'quiz_admin_user';

  constructor(private authService: AuthService, 
    private router: Router,
    @Inject(SESSION_STORAGE) private storage:StorageService) { }

  ngOnInit() {
    this.authService.authState.subscribe((user) => {
      this.user = user;
      if(this.user){
        this.router.navigate(['/dashboard']);
      }
    });
  }

  signInWithGoogle(): void {
    this.authService.signIn(GoogleLoginProvider.PROVIDER_ID).then(
      (userData) => {
        // insert updated array to local storage
        this.storage.set(this.STORAGE_KEY, 1);
        this.router.navigate(['/dashboard']);    
      }
    );
  }

  signInWithFB(): void {
    this.authService.signIn(FacebookLoginProvider.PROVIDER_ID).then(
      (userData) => {
        // insert updated array to local storage
        this.storage.set(this.STORAGE_KEY, 1);
        this.router.navigate(['/dashboard']);    
      }
    );
  }

  

}
