import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Location } from '@angular/common';

@Component({
  selector: 'app-add-voucher',
  templateUrl: './add-voucher.component.html',
  styleUrls: ['./add-voucher.component.css']
})
export class AddVoucherComponent implements OnInit {
  
  campaigns:any;
  prizePointNeeded:any;
  prizeDescription:any;
  selectedCampaign:any;

  constructor(private http: HttpClient,
    private location: Location) { }

  ngOnInit() {
    this.http.get('http://localhost:3000/campaign/getCampaigns').subscribe(data => {
      this.campaigns = data;
    });
  }
 

  createPrize(){
    this.http.post('http://localhost:3000/prize/createPrize',{data:{
      idCampaign:this.selectedCampaign,
      description:this.prizeDescription,
      pointsRequired:this.prizePointNeeded,
    }}).subscribe(data => {
      this.location.back();
    });
  }



}

