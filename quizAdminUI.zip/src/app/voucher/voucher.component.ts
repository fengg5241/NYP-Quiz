import { Component, OnInit } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Location } from '@angular/common';
@Component({
  selector: 'app-voucher',
  templateUrl: './voucher.component.html',
  styleUrls: ['./voucher.component.css']
})

export class VoucherComponent implements OnInit {

  model = {
    left: true,
    middle: false,
    right: false
  };

  prizes:any;
  
  constructor(private http: HttpClient,
    private location: Location) { }

  ngOnInit() {
    //search all categories
    this.http.get('http://localhost:3000/prize/getPrizes').subscribe(data => {
      this.prizes = data;
    });
}

deleteVoucher(id){
  if(window.confirm('Are you sure you want to delete this voucher?')){
  this.http.get('http://localhost:3000/prize/deletePrize/'+id).
    subscribe(data => {
      location.reload();
  });
 }
}
}
