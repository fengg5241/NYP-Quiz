import { element } from 'protractor';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
//import * as jsPDF from 'jspdf';

@Component({
  selector: 'app-logbook',
  templateUrl: './logbook.component.html',
  styleUrls: ['./logbook.component.css']
})
export class LogbookComponent implements OnInit {

 //  Export to PDF function
   //@ViewChild('content') content: ElementRef;

  //public downloadPDF(){

  //let doc = new jsPDF();

  //let specialElementHandlers = {
 //'#editor': function(element, renderer){
 //return true;
 //}

 
 //};

 //let content = this.content.nativeElement;

  //doc.fromHTML(content.innerHTML, 15, 15, {
 //'width': 190,
 //'elementHandlers': specialElementHandlers
 //});

  //doc.save('logbook.pdf');
  //} 

  public downloadCSV(csv, filename) {
    var csvFile;
    var downloadLink;
  
    csvFile = new Blob([csv],{type:"text/csv"});
  
    downloadLink = document.createElement("a");
    downloadLink.download = filename;
    downloadLink.href = window.URL.createObjectURL(csvFile);
    downloadLink.style.display = "none";
  
    document.body.appendChild(downloadLink);
  
    downloadLink.click();
  }
  
  public exportTableToCSV(filename){
  var csv = [];
  var rows = document.querySelectorAll("table tr");
  
    for(var i = 0; i < rows.length; i++){
      var row = [], cols = rows[i].querySelectorAll("td, th");
      for(var j = 0; j < cols.length; j++)
        row.push(cols[j].innerHTML);
  
      csv.push(row.join(","));
    }
  
    //download csv file
    this.downloadCSV(csv.join("\n"),filename);
  }


  
 model = {
   left: true,
   middle: false,
    right: false 
  };

 redemptions:any;
  
constructor(private http: HttpClient) { }

  ngOnInit() {
   // search all categories
    this.http.get('http://localhost:3000/redemption/getRedemption').subscribe(data => {
    this.redemptions = data;
    });
  }
}
