import { AddAdminComponent } from './add-admin/add-admin.component';
import { AdminsComponent } from './admins/admins.component';
import { AddVoucherComponent } from './add-voucher/add-voucher.component';
import { NgModule, Component } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CategoryComponent } from './category/category.component';
import { VoucherComponent } from './voucher/voucher.component';
import { AddCategoryComponent } from './add-category/add-category.component';
import { QuestionComponent } from './question/question.component';
import { ViewQuestionComponent } from './view-question/view-question.component';
import { CampaignComponent } from './campaign/campaign.component';
import { ViewCampaignComponent } from './view-campaign/view-campaign.component';
import { UsersComponent } from './users/users.component';
import { QuestionDetailComponent } from './question-detail/question-detail.component';
import { CampaignDetailComponent } from './campaign-detail/campaign-detail.component';
import { LogbookComponent } from './logbook/logbook.component';
import { CategoryDetailComponent } from './category-detail/category-detail.component';
import { LoginComponent } from './login/login.component';
import { TimeLimitComponent } from './time-limit/time-limit.component';



const routes: Routes = [
  { path: 'dashboard', component: DashboardComponent },
  { path: 'category', component: CategoryComponent },
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  { path: 'voucher', component: VoucherComponent },
  { path: 'addCategory', component: AddCategoryComponent },
  { path: 'question', component: QuestionComponent },
  { path: 'viewQuestion', component: ViewQuestionComponent},
  { path: 'campaign', component:CampaignComponent},
  { path: 'viewCampaign', component:ViewCampaignComponent},
  { path: 'questionDetail', component:QuestionDetailComponent},
  { path: 'campaign', component:CampaignComponent},
  { path: 'users', component:UsersComponent},
  { path: 'campaignDetail', component:CampaignDetailComponent},
  { path: 'categoryDetail', component:CategoryDetailComponent},
  { path: 'categoryDetail/:id', component:CategoryDetailComponent},
  { path: 'questionDetail/:id', component:QuestionDetailComponent},
  { path: 'campaignDetail/:id', component:CampaignDetailComponent},
  { path: 'categoryDetail/:id', component:CategoryDetailComponent},
  { path: 'logbook', component:LogbookComponent},
  { path: 'categoryDetail', component:CategoryDetailComponent},
  { path: 'addVoucher', component:AddVoucherComponent},
  { path: 'admins', component:AdminsComponent},
  { path: 'login', component:LoginComponent},
  { path: 'addAdmin', component:AddAdminComponent},
  { path: 'timeLimit', component:TimeLimitComponent},
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' }
]
@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }
