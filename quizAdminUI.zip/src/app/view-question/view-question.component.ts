import { Component, OnInit } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-view-question',
  templateUrl: './view-question.component.html',
  styleUrls: ['./view-question.component.css']
})
export class ViewQuestionComponent implements OnInit {
/* questions:Object[] = [
  {
     id:1,
      category:"Life",
      diffLevel:"easy",
      title:"1234556"
    },
    {
      id:2,
      category:"Lif11",
      diffLevel:"Hard",
      title:"555555555"
    },
    {
      id:3,
      category:"ggggg",
      diffLevel:"easy",
      title:"9999999999"
    }
  ];

  categories:Object[] = [
    {
      id:0,
      name:""
    },
    {
      id:1,
      name:"life"
    },
    {
      id:2,
      name:"study"
    }
  ];
  constructor() { }

  ngOnInit() {
  }

  filterQuestions(){
    alert(1);
  }*/
  model = {
    left: true,
    middle: false,
    right: false
  };

  questions:any;
  categories:any;
  selectedCategory:any;
  selectedDiffLel:any;
  searchKeyword:any;

  constructor(private http: HttpClient) { }

  ngOnInit() {
    //search all categories
    this.http.get('http://localhost:3000/question/getQuestions').subscribe(data => {
      this.questions = data;
    });
    this.http.get('http://localhost:3000/category/getCategories').subscribe(data => {
      this.categories = data;
  });
  }

  diffLvlMap = {1:'easy',2:'medium',3:'hard'};
  displayDiffLvlStr(diffLvl){
    return this.diffLvlMap[diffLvl];
  }


  filterQuestions(){
    var condition = {};
    if(this.selectedCategory != 0){
      condition["idCategory"] = this.selectedCategory;
    }
    if(this.selectedDiffLel != 0){
      condition["lvlDifficulty"] = this.selectedDiffLel;
    }
    // if(this.searchKeyword != 0){
    //   condition["content"] = this.searchKeyword;
    // }

    this.http.post('http://localhost:3000/question/getQuestionsByCondition',
    {data:condition}).subscribe(data => {
      this. questions = data;
    });
  }


}
