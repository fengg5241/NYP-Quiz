import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Location } from '@angular/common';

@Component({
  selector: 'app-add-category',
  templateUrl: './add-category.component.html',
  styleUrls: ['./add-category.component.css']
})
export class AddCategoryComponent implements OnInit {



  campaigns:any;
  categoryName:any;
//noOfQuestions:any;
  selectedCampaign:any;


  constructor(private http: HttpClient,
    private location: Location) { }



  ngOnInit() {
    this.http.get('http://localhost:3000/campaign/getCampaigns').subscribe(data => {
      this.campaigns = data;
    });
  }

 

  createCategory(){
    this.http.post('http://localhost:3000/category/createCategory',{data:{
      idCampaign:this.selectedCampaign,
      name:this.categoryName,
    }}).subscribe(data => {
      this.location.back();
    });
  }



}
