import { Component, OnInit } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
// import the file uploader plugin
import {  FileUploader } from 'ng2-file-upload/ng2-file-upload';

// define the constant url we would be uploading to.
const URL = 'http://localhost:3000/question/upload';

@Component({
  selector: 'app-question-detail',
  templateUrl: './question-detail.component.html',
  styleUrls: ['./question-detail.component.css']
})

export class QuestionDetailComponent implements OnInit {


  model = {
    left: true,
    middle: false,
    right: false
  };

  curQuestion:any;
  newQuestion:any;
  wrongAns1 ="";
  wrongAns2 ="";
  wrongAns3 ="";


  editMode = false;

  diffLvlMap = {1:'easy',2:'medium',3:'hard'};
  displayDiffLvlStr(diffLvl){
    return this.diffLvlMap[diffLvl];
  }

  // declare a property called fileuploader and assign it to an instance of a new fileUploader.
    // pass in the Url to be uploaded to, and pass the itemAlais, which would be the name of the //file input when sending the post request.
    public uploader: FileUploader = new FileUploader({url: URL, itemAlias: 'photo'});
    uploadedFileName:String;
    serverUploadFolder = "http://localhost:3000/images/uploads/question/";
  constructor(private http: HttpClient,
    private route: ActivatedRoute,
    private location: Location) { }

  ngOnInit() {
    var questionId = this.route.snapshot.paramMap.get('id');
    this.http.get('http://localhost:3000/question/getQuestion/'+questionId).subscribe(data => {
      this.curQuestion = data;
      var wrongAnsStr = this.curQuestion.content.wrongAns;
      var wrongAnsArray = wrongAnsStr.split("/$/");
      for(var i=1;i<=wrongAnsArray.length;i++){
        this["wrongAns"+i] = wrongAnsArray[i-1];
      }
    });

    // override the onAfterAddingfile property of the uploader so it doesn't authenticate with //credentials.
    this.uploader.onAfterAddingFile = (file) => { file.withCredentials = false;};
    // overide the onCompleteItem property of the uploader so we are
    // able to deal with the server response.
    this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
         this.uploadedFileName = JSON.parse(response).filename;
         alert("Upload Successful !");
         console.log('ImageUpload:uploaded:', item, status, response);
     };
  }

  changeEditMode(){
    this.editMode = !this.editMode;
    this.newQuestion= Object.assign({}, this.curQuestion);
  }

  saveCategory(){
    this.newQuestion.content.wrongAns = "";
    if(this.wrongAns1 != ""){
      this.newQuestion.content.wrongAns += this.wrongAns1 + '/$/';
      }
      if(this.wrongAns2 != ""){
        this.newQuestion.content.wrongAns += this.wrongAns2 + '/$/';
      }
      if(this.wrongAns3 != ""){
        this.newQuestion.content.wrongAns += this.wrongAns3;
      }

      this.newQuestion.content.image = this.uploadedFileName;

    this.http.post('http://localhost:3000/question/updateQuestion/',
      {data:this.newQuestion}).subscribe(data => {
        this.curQuestion = data;
        this.changeEditMode();
    });
  }

  deleteCategory(){
    this.http.get('http://localhost:3000/question/deleteQuestion/'+this.curQuestion.id).
      subscribe(data => {
        this.location.back();
    });

  }

}


