import { Component, OnInit } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Location } from '@angular/common';
import {  FileUploader } from 'ng2-file-upload/ng2-file-upload';

const URL = 'http://localhost:3000/question/upload';
@Component({
  selector: 'app-question',
  templateUrl: './question.component.html',
  styleUrls: ['./question.component.css']
})
export class QuestionComponent implements OnInit {

  wrongAns1 = "";
  wrongAns2 = "";
  wrongAns3 = "";

  newQuestion = {
    idCategory:"",
    lvlDifficulty:1,
    msTimeLimit:60,
    pointWeight:1,
    content:{
        title:"",
        image:"",
        wrongAns:"",
        correctAns:""
    }
  }
  add=false;
  
  diffLvlMap = {1:'easy',2:'medium',3:'hard'};
  displayDiffLvlStr(diffLvl){
    return this.diffLvlMap[diffLvl];
  }

  categories:any;

  public uploader: FileUploader = new FileUploader({url: URL, itemAlias: 'photo'});
  uploadedFileName:string;
  serverUploadFolder = "http://localhost:3000/images/uploads/question/";
  constructor(private http: HttpClient,
    private location: Location) { }
 
  ngOnInit() {

    //search all categories
    this.http.get('http://localhost:3000/category/getCategories').subscribe(data => {
      this.categories = data;
    });

     // override the onAfterAddingfile property of the uploader so it doesn't authenticate with //credentials.
     this.uploader.onAfterAddingFile = (file) => { file.withCredentials = false;};
     // overide the onCompleteItem property of the uploader so we are
     // able to deal with the server response.
     this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
          this.uploadedFileName = JSON.parse(response).filename;
          alert("Upload Successful !");
          console.log('ImageUpload:uploaded:', item, status, response);
      };
  }

  createQuestion(){
  
    if(this.wrongAns1 != ""){
    this.newQuestion.content.wrongAns += this.wrongAns1 + '/$/';
    }
    if(this.wrongAns2 != ""){
      this.newQuestion.content.wrongAns += this.wrongAns2 + '/$/';
    }
    if(this.wrongAns3 != ""){
      this.newQuestion.content.wrongAns += this.wrongAns3;
    }
   this.newQuestion.content.image = this.uploadedFileName;

    this.http.post('http://localhost:3000/question/createQuestion',{data:this.newQuestion}).subscribe(data => {
      this.location.back();
    });
  }


}
