import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-admins',
  templateUrl: './admins.component.html',
  styleUrls: ['./admins.component.css']
})
export class AdminsComponent implements OnInit {

  model = {
    left: true,
    middle: false,
    right: false 
  };

  admins:any;
  
  constructor(private http: HttpClient) { }

  ngOnInit() {
    //search all categories
    this.http.get('http://localhost:3000/admins/getAdmins').subscribe(data => {
      this.admins = data;
    });
  }

  deleteAdmin(id){
    if(window.confirm('Are you sure you want to delete this admin?')){
    this.http.get('http://localhost:3000/admins/deleteAdmins/'+id).
      subscribe(data => {
        location.reload();
    });
   }
  }
}