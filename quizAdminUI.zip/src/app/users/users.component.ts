import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  model = {
    left: true,
    middle: false,
    right: false 
  };

  users:any;
  
  constructor(private http: HttpClient) { }

  ngOnInit() {
    //search all categories
    this.http.get('http://localhost:3000/users/getUsers').subscribe(data => {
      this.users = data;
    });
  }
}