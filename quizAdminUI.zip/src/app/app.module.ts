import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './/app-routing.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CategoryComponent } from './category/category.component';
import { VoucherComponent } from './voucher/voucher.component';
import { AddCategoryComponent } from './add-category/add-category.component';
import { QuestionComponent } from './question/question.component';
import { ViewQuestionComponent } from './view-question/view-question.component';
import { CampaignComponent } from './campaign/campaign.component';
import { ViewCampaignComponent } from './view-campaign/view-campaign.component';
import { QuestionDetailComponent } from './question-detail/question-detail.component';
import { UsersComponent } from './users/users.component';
import { AdminsComponent } from './admins/admins.component';
import { CampaignDetailComponent } from './campaign-detail/campaign-detail.component';
import { LogbookComponent } from './logbook/logbook.component';
import { CategoryDetailComponent } from './category-detail/category-detail.component';
import { AddVoucherComponent } from './add-voucher/add-voucher.component';
import { LoginComponent } from './login/login.component';
import {
  SocialLoginModule,
  AuthServiceConfig,
  GoogleLoginProvider,
  FacebookLoginProvider,
} from "angular-6-social-login";
import { StorageServiceModule } from 'angular-webstorage-service';
import { HeaderComponent } from './header/header.component';
import { AddAdminComponent } from './add-admin/add-admin.component';
import { TimeLimitComponent } from './time-limit/time-limit.component';
// import the ng2-file-upload directive so we can add it to our declarations.
import { FileSelectDirective } from 'ng2-file-upload';


// Configs 
export function getAuthServiceConfigs() {
  let config = new AuthServiceConfig(
      [
        {
          id: FacebookLoginProvider.PROVIDER_ID,
          provider: new FacebookLoginProvider("2231141883577777")
        },
        {
          id: GoogleLoginProvider.PROVIDER_ID,
          provider: new GoogleLoginProvider("624796833023-clhjgupm0pu6vgga7k5i5bsfp6qp6egh.apps.googleusercontent.com")
        }
      ]
  );
  return config;
}

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    CategoryComponent,
    VoucherComponent,
    AddCategoryComponent,
    QuestionComponent,
    ViewQuestionComponent,
    CampaignComponent,
    ViewCampaignComponent,
    QuestionDetailComponent,
    CampaignComponent,
    UsersComponent,
    AdminsComponent,
    CampaignDetailComponent,
    LogbookComponent,
    CategoryDetailComponent,
    AddVoucherComponent,
    LoginComponent,
    HeaderComponent,
    AddAdminComponent,
    TimeLimitComponent,
    FileSelectDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    SocialLoginModule,
    StorageServiceModule,
    
  ],
  providers: [{
    provide: AuthServiceConfig,
    useFactory: getAuthServiceConfigs
  
  }],
  
  bootstrap: [AppComponent]
})
export class AppModule { }
