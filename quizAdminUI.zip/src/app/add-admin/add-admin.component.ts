import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Location } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-admin',
  templateUrl: './add-admin.component.html',
  styleUrls: ['./add-admin.component.css']
})
export class AddAdminComponent implements OnInit {

  constructor(private http: HttpClient,
    private location: Location,
    private router: Router) { }

  ngOnInit() {
  }

  userID:any;
  Username:any;
  Branch:any;
 // todayDateTime = new Date().toISOString().slice(0,10);

  createAdmin(){
    this.http.post('http://localhost:3000/admins/createAdmins',{data:{
      idUser:this.userID,
      userName:this.Username,
      branch:this.Branch,
    //  utcCreated:this.todayDateTime,
    }}).subscribe(data => {
      this.router.navigate(['/admins']);    
    });
  }
}
