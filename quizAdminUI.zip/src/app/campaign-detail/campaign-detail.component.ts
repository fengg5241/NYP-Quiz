import { Component, OnInit } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import {  FileUploader } from 'ng2-file-upload/ng2-file-upload';

// define the constant url we would be uploading to.
const URL = 'http://localhost:3000/campaign/upload';

@Component({
  selector: 'app-campaign-detail',
  templateUrl: './campaign-detail.component.html',
  styleUrls: ['./campaign-detail.component.css']
})
export class CampaignDetailComponent implements OnInit {

  model = {
    left: true,
    middle: false,
    right: false
  };

  curCampaign:any;

  newCampaign:any;

  editMode = false;

  todayDateTime = new Date().toISOString().slice(0,10);

  public uploader: FileUploader = new FileUploader({url: URL, itemAlias: 'photo'});
  uploadedFileName:String;
  serverUploadFolder = "http://localhost:3000/images/uploads/campaign/";

  constructor(private http: HttpClient,
    private route: ActivatedRoute,
    private location: Location) { }

  ngOnInit() {
    var campaignId = this.route.snapshot.paramMap.get('id');
    this.http.get('http://localhost:3000/campaign/getCampaign/'+campaignId).subscribe(data => {
      this.curCampaign= data;
      this.curCampaign.utcRelease = new Date(this.curCampaign.utcRelease).toISOString().slice(0,10);
      this.curCampaign.utcEnd = new Date(this.curCampaign.utcEnd).toISOString().slice(0,10);
    });
      // override the onAfterAddingfile property of the uploader so it doesn't authenticate with //credentials.
      this.uploader.onAfterAddingFile = (file) => { file.withCredentials = false;};
      // overide the onCompleteItem property of the uploader so we are
      // able to deal with the server response.
      this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
           this.uploadedFileName = JSON.parse(response).filename;
           alert("Upload Successful !");
           console.log('ImageUpload:uploaded:', item, status, response);
       };
  }

  changeEditMode(){
    this.editMode = !this.editMode;
    this.newCampaign= Object.assign({}, this.curCampaign);
  }

  saveCampaign(){
    
    this.http.post('http://localhost:4000/campaign/updateCampaign',
      {data:this.newCampaign}).subscribe(data => {
        this.curCampaign = data;
        this.curCampaign.image = this.uploadedFileName;
        this.curCampaign.utcRelease = new Date(this.curCampaign.utcRelease).toISOString().slice(0,10);
        this.curCampaign.utcEnd = new Date(this.curCampaign.utcEnd).toISOString().slice(0,10);
        this.changeEditMode();

    });
  }

  deleteCampaign(){
    this.http.get('http://localhost:4000/campaign/deleteCampaign/'+this.curCampaign.id).
      subscribe(data => {
        if(data["error"]){
          alert("xx");
        }else {
          this.location.back();
        }
      });
    }
  }
