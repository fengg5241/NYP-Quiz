import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Location } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-time-limit',
  templateUrl: './time-limit.component.html',
  styleUrls: ['./time-limit.component.css']
})
export class TimeLimitComponent implements OnInit {
  EasyTimeLimit:any;
  MediumTimeLimit:any;
  HardTimeLimit:any;

 constructor( private http: HttpClient,
              private router: Router,
              private location: Location) { }
          
  
  
    ngOnInit() {
    }
  
   
  
    storeTimeLimit(){
      this.http.post('http://localhost:3000/category/createCategory',{data:{
        msTimeLimit:this.EasyTimeLimit,
      }}).subscribe(data => {
        this.router.navigate(['viewQuestion']);
      });
    }
  
  
  
  }
  