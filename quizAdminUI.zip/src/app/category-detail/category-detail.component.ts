import { Component, OnInit } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-category-detail',
  templateUrl: './category-detail.component.html',
  styleUrls: ['./category-detail.component.css']
})
export class CategoryDetailComponent implements OnInit {

  model = {
    left: true,
    middle: false,
    right: false
  };

  categories:any;
  curCategory:any;
  questions:any;
  newCategory:any;
  campaigns:any;

  editMode = false;

  constructor(private http: HttpClient,
    private route: ActivatedRoute,
    private location: Location) { }

  ngOnInit() {
    var categoryId = this.route.snapshot.paramMap.get('id');
    this.http.get('http://localhost:3000/category/getCategory/'+categoryId).subscribe(data => {
      this.curCategory = data;


    });
    this.http.get('http://localhost:3000/campaign/getCampaigns').subscribe(data => {
      this.campaigns = data;
    });
  
    this.http.get('http://localhost:3000/question/getQuestionsByCatId/'+categoryId).subscribe(data => {
      if(data instanceof Array ){
        this.questions = data;
      }else {
        this.questions = [];
        this.questions.push(data);
      }
     
   
    });
  }

  changeEditMode(){
    this.editMode = !this.editMode;
    this.newCategory= Object.assign({}, this.curCategory);
  }

  saveCategory(){
    
    this.http.post('http://localhost:4000/category/updateCategory',
      {data:this.newCategory}).subscribe(data => {
        this.curCategory = data;
        this.changeEditMode();
    });
  }

  deleteCategory(){
    this.http.get('http://localhost:4000/category/deleteCategory/'+this.curCategory.id).
      subscribe(data => {
        this.location.back();
    });

  }

  diffLvlMap = {1:'easy',2:'medium',3:'hard'};
  displayDiffLvlStr(diffLvl){
    return this.diffLvlMap[diffLvl];
  }

}
